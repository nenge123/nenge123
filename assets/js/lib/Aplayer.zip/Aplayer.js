/**
 * Nenge remake
 * copy from APlayer
 */
class Aplayer extends EventTarget{
    handleOption(options) {
        const defaultOption = {
            mini:undefined,//T.isTouch?true:false,//undefine close
            fixed:true,//top botton top|left ....
            preload: 'auto',
            loop: false,//once random
            order:true,//true:list false:random
            volume: T.isTouch?1:0.5,
            audio:[{
                name: "久别重逢666",
                artist: "HANA",
                url: "/github/my-aplayer/1.m4a",
                lrc: "/github/my-aplayer/gbk.lrc",
                charset: "gbk",
                type: "m4a",
                cover: "/github/my-aplayer/cover.jpg"
            }],
            iconsFace:'aplayer-icon',
            iconsurl:'',//font data
            iconsBtn:{"play":"ee01","pause":"ee02","volumeUp":"ee03","volumeDown":"ee04","volumeOff":"ee05","orderRandom":"ee06","orderList":"ee07","menu":"ee08","loopAll":"ee09","loopOne":"ee0a","loopNone":"ee0b","loading":"ee0c","right":"ee0d","skip":"ee0e","lrc":"ee0f"}
        };
        Object.assign(this,defaultOption,options);
        if(this.fixed&&!this.mini){
            this.mini = T.isTouch?true:false;
        }
    }
    events = [
        'abort',//0
        'canplay',//1
        'canplaythrough',//2
        'durationchange',//3
        'emptied',//4
        'ended',//5
        'error',//6
        'loadeddata',//7
        'loadedmetadata',//8
        'loadstart',//9
        'mozaudioavailable',//10
        'pause',//11
        'play',//12
        'playing',//13
        'progress',//14
        'ratechange',//15
        'seeked',//16
        'seeking',//17
        'stalled',//18
        'suspend',//19
        'timeupdate',//20
        'volumechange',//21
        'waiting',//22
    ];
    Elm = {};
    RuleKey = {};
    constructor(options, player){
        super();
        this.handleOption(options);
        this.container = this.appendChild(this.creatElm('div'),this.container||document.body);
        this.Store = T.getTable('music',{type:false});
        try{
        this.initTpl();
        }catch(e){alert(e);}
    }
    creatElm(str){
        return document.createElement(str);
    }
    appendChild(elm1,elm2){
        if(!elm2)elm2 = this.container;
        return elm2.appendChild(elm1);
    }
    getURL(url){
        
    }
    getData(){
        return this.audio[this.index];
    }
    async play(index){
        const aplayer = this;
        const audio = aplayer.audioElm;
        if(!aplayer.audio[index])index = 0;
        aplayer.index = index;
        let {type,url,cover,name,artist} = aplayer.getData();
        //audio.pause();
        if(I.fn(url)){
            url = await url();
            this.audio[index].url = url;
        }
        if(I.blob(url)){
            url = F.URL(url,'mp3');
            this.audio[index].url = url;
        }
        audio.src = url;
        //audio.currentTime = 0;
        audio.setAttribute('type',F.getMime(type||url));
        //aplayer.Elm['timebar'].style.width='0%';
        aplayer.Elm['title'].innerHTML = name||'';
        aplayer.Elm['author'].innerHTML = artist||'';
        aplayer.readLRC();
        aplayer.css.pushCSS('background-image: '+(cover?'url('+cover+')':'none')+';',aplayer.RuleKey['picindex']);
    }
    next(){
        if(!this.order&&this.audio.length>=3) return this.random();
        let index = this.index+1;
        if(index == this.audio.length || !index)index=0;
        console.log(index);
        if(this.audio[index])this.play(index);
    }
    prev(){
        if(!this.order&&this.audio.length>=3) return this.random();
        let index = this.index-1;
        if(!this.audio[index])index=this.audio.length-1;
        if(this.audio[index])this.play(index);
    }
    random(){
        if(this.audio.length<3)return this.next();
        let index = Math.floor(Math.random()*this.audio.length);
        if(index>=this.audio.length)index = this.audio.length-1;
        if(this.audio[index])this.play(index);

    }
    async initAudio(){
        const aplayer = this;
        const events = aplayer.events;
        events.forEach(v=>aplayer.audioElm.on(v,function(e){
            const currentTime = this.currentTime;
            const duration = this.duration;
            switch(e.type){
                case events[20]:
                    //timeupdate
                    aplayer.updateLRC(currentTime);
                break;
                case events[11]:
                    //pause
                    aplayer.toEvent('play',!1);
                break;
                case events[12]:
                    //play
                    aplayer.toEvent('play',!0);
                break;
                case events[2]:
                    //canplaythrough
                    this.play().catch((a,b,c)=>{
                        if(a.code===0){
                            aplayer.container.once('click',e=>{
                                this.play();
                            });
                        }
                    });
                break;
                case events[5]:
                    //ended
                    aplayer.next();
                break;
                case events[6]:
                    //error
                    aplayer.audio.splice(aplayer.index,1);
                    aplayer.play(aplayer.index);
                    aplayer.outMusic();
                break;
                default:
                    console.log(e.type);
                break;
            }
        }));
        if(!aplayer.audio.length)return;
        T.docload(e=>{
            if(aplayer.order){
                aplayer.play(0);
            }else{
                aplayer.random();
            }
        });
    }
    initTpl(){
        const aplayer = this;
        const icons = this.iconsBtn;
        const fontName = this.iconsFace;
        const fontface = `font-family:"${fontName}";`;
        const bodyHeight = '66px';
        const bodyWidth = '380px';
        const btnSize = '20px';
        const HTML = document.createDocumentFragment();
        const RuleIndex = T.css.Elm2Rule(this.container,`
        width:90%;
        margin:0px auto;
        box-shadow: 0 2px 2px 0 #00000012, 0 1px 5px 0 #0000001a;
        border-radius: 2px;
        user-select: none;
        line-height: initial;user-select: none;`);
        const css = T.css.NewRule(RuleIndex);
        const fontList = css.fontList();
        if(!fontList.includes(fontName)){
            css.addFont(aplayer.iconsurl||aplayer.fontData(),fontName);
        }
        aplayer.container.on('touchdown',function(e){
            e.preventDefault();
            e.stopPropagation();
        });
        css.addRule(`[hidden]{display:none !important;}`);
        const bodyElm = this.appendChild(this.creatElm('div'),HTML);
        let bodyElmIndex =  css.Elm2Rule(bodyElm,`
        background-color: #fff;color:#000;
        height:${bodyHeight};
        display: flex;
        flex-wrap: nowrap;
        flex-direction: row;
        justify-content: flex-start;
        align-items: space-between;`);
        //艺术图
        const picElm = this.appendChild(this.creatElm('div'),bodyElm);
        let picindex = css.Elm2Rule(picElm,`
        position: relative;
        width:${bodyHeight};
        background-repeat: no-repeat;
        background-color: #ebd0c2;
        background-size: cover;
        background-color:#000;
        order:2;
        transition: all 0.3s ease;`);
        //信息窗体
        const infoElm = this.appendChild(this.creatElm('div'),bodyElm);
        css.Elm2Rule(infoElm,`
        position: relative;
        flex-grow: 1;
        box-sizing: border-box;
        opacity: 1;
        transition: all ease-in .1s;
        display: flex;
        flex-direction: column;
        align-items: stretch;
        justify-content: center;order:3;`);
        //歌词
        const lrcElm = this.appendChild(this.creatElm('div'),HTML);
        const lrcTextElm = this.appendChild(this.creatElm('div'),lrcElm);
        const lrcElmIndex = css.Elm2Rule(lrcElm,`padding-top: 50px;
        height: 80px;
        overflow: hidden;
        max-height: 300px;pointer-events: none;`);
        css.Elm2Rule(lrcTextElm,`transition: all 0.5s ease-out;`);
        css.Elm2Rule(lrcTextElm,`font-size: 12px;
        color: #666;
        opacity: .6;
        transition: all 0.5s ease-out;
        margin: 0;
        word-wrap: break-word;
        width: 100%;
        text-wrap: balance;
        text-align: center;`,!0,' p');
        css.Elm2Rule(lrcTextElm,`color:#000;opacity:1;transform: scale(1.2);margin:5px;`,!0,' p.active');
        //列表
        const listElm = this.appendChild(this.creatElm('div'),HTML);
        css.Elm2Rule(listElm,`transition: all 0.5s ease-out;overflow: hidden;
        position: absolute;
        bottom: 100%;
        right: 0px;margin-bottom:40px;z-index: 2;border-radius: 5px;
        border: 1px #dfdfdf solid;
        right: 10px;
        box-shadow: 0px 0px 5px 1px #ccc;
        background: #ffffff47;`);
        css.Elm2Rule(listElm,`width:${bodyWidth};height:200px;overflow-y: auto;`,!0,'.active');
        css.Elm2Rule(listElm,`width: 0px;height:0px;`,!0,':not([class~="active"])');
        const listUlElm = this.appendChild(this.creatElm('ul'),listElm);
        css.Elm2Rule(listUlElm,`padding:5px;margin:0px;`);
        css.Elm2Rule(listUlElm,`display: flex;justify-content: space-between;border: 1px solid #ccc;
        margin: 5px auto;
        padding: 5px;
        background: #24649b;
        color: #fff;
        border-radius: 6px;transition: all .5s;`,!0,' li');
        css.Elm2Rule(listUlElm,`background: #e77e30;`,!0,' li:hover');
        aplayer.outMusic(listUlElm);
        //信息窗体 歌曲名
        const headElm = this.appendChild(this.creatElm('div'),infoElm);
        css.Elm2Rule(headElm,`cursor: grabbing;flex-grow:1;display: flex;align-items: center;justify-content: center;font-size:18px;`);
        const rubyElm = this.appendChild(this.creatElm('ruby'),headElm);
        const titleElm = this.appendChild(this.creatElm('span'),rubyElm);
        const authorElm = this.appendChild(this.creatElm('rt'),rubyElm);
        css.Elm2Rule(authorElm,'text-align: right;');
        titleElm.innerHTML = '能哥网';
        authorElm.innerHTML = 'Nenge.net    ';
        //信息窗体 控制区
        const ctrlElm = this.appendChild(this.creatElm('div'),infoElm);
        css.Elm2Rule(ctrlElm,`
        display: flex;
        justify-content: space-between;
        align-items: center;height:20px;`);
        const audio = this.appendChild(this.creatElm('audio'),ctrlElm);
        aplayer.audioElm = audio;
        ['volume','loop','preload'].forEach(v=>audio[v]=aplayer[v]);
        audio.controls = !0;
        css.Elm2Rule(audio,`height:20px;width:95%;appearance: none;background: transparent;margin:0px auto;`);
        css.Elm2Rule(audio,`background: transparent;border-radius:none;`,!0,'::-webkit-media-controls-enclosure');
        css.Elm2Rule(audio,`background: transparent;`,!0,'::-webkit-media-controls');
        css.Elm2Rule(audio,`background: transparent;border-radius:none;`,!0,'::-webkit-media-controls-panel');
        const btnElm = this.appendChild(this.creatElm('div'),infoElm);
        css.Elm2Rule(btnElm,`
        display: flex;
        justify-content: flex-end;
        align-items: center;
        flex-wrap: nowrap;
        position: absolute;
        bottom: 100%;
        right: 0px;z-index:1;`);
        this.ctrlElm = I.toArr(['skip','skip','volumeDown','orderList','loopAll','lrc','menu'],(v,index)=>{
            const wrap = this.appendChild(this.creatElm('div'),btnElm);
            const btn = this.appendChild(this.creatElm('button'),wrap);
            css.Elm2Rule(btn,`border: none;
            background: transparent;
            color:#8696a5;
            width: ${btnSize};
            height: ${btnSize};
            display: block;
            text-align: center;
            line-height: ${btnSize};
            ${fontface};
            padding: 0px;
            margin: 0px 2px;font-size: 12px;`);
            if(index==2){
                const wrapbar = this.appendChild(this.creatElm('div'),wrap);
                const barH = this.appendChild(this.creatElm('div'),wrapbar);
                css.Elm2Rule(wrap,`display:flex;`,!0,'.active >div');
                css.Elm2Rule(btn,`text-indent: 4px;`);
                css.Elm2Rule(wrap,`position: relative;`);
                css.Elm2Rule(wrapbar,`display: flex;flex-direction: column;justify-content: flex-end;width:5px;height:35px;position: absolute;bottom:100%;background: #cdcdcd;border-radius: 2.5px;margin: 0px auto;left: 0;right: 0;bottom: 100%;display:none;`);
                css.Elm2Rule(wrap,'display:;',!0,'hover')
                css.Elm2Rule(barH,`width:5px;height:15px;background: #ebd0c2;border-radius: 2.5px;`);
                aplayer.Elm['volume'] = barH;
                wrapbar.on('pointermove',function(e){
                    this.toEvent('pointerdown',e.clientY);
                    e.preventDefault();
                });
                wrapbar.on('pointerup',function(e){
                    this.toEvent('pointerdown',e.clientY);
                    e.preventDefault();
                });
                wrapbar.on('pointerdown',function(e){
                    let y = e.clientY||e.detail;
                    let {top,height} = this.getBoundingClientRect();
                    let per = 1-(y-top)/height;
                    if(per>1)per=1;
                    if(per<0)per=0;
                    aplayer.audioElm.volume = per;
                    e.preventDefault();
                });
            }else if(index==1){
                css.Elm2Rule(btn,`transform: rotate(180deg);`);
            }
            btn.setAttribute('data-index',index);
            btn.on('pointerup',function(e){
                switch(parseInt(this.dataset.index)){
                    case 0:
                    aplayer.prev();
                    break;
                    case 1:
                    aplayer.next();
                    break;
                    case 2:
                        this.parentNode.classList.toggle('active');
                    break;
                    case 3:
                        aplayer.order = !aplayer.order;
                        this.innerHTML = `&#${parseInt(icons[aplayer.order?'orderList':'orderRandom'],16)};`;
                    break;
                    case 4:
                        let loop = aplayer.loop;
                        if(loop===false){
                            loop = true;
                            this.innerHTML = `&#${parseInt(icons['loopOne'],16)};`;
                        }else if(loop===true){
                            loop = undefined;
                            this.innerHTML = `&#${parseInt(icons['loopNone'],16)};`;
                        }else if(loop===undefined){
                            loop = false;
                            this.innerHTML = `&#${parseInt(icons['loopAll'],16)};`;
                        }
                        aplayer.audioElm.loop = loop;
                        aplayer.loop = loop;
                    break;
                    case 5:
                        if(I.nil(aplayer.hideLRC))aplayer.hideLRC = lrcElm.hidden;
                        lrcElm.hidden = !aplayer.hideLRC;
                        aplayer.hideLRC = !aplayer.hideLRC;
                    break;
                    case 6:
                        listElm.classList.toggle('active');
                    break;
                }
            });
            css.Elm2Rule(btn,`background:#f9f1f1;color:#000;`,undefined,':hover');
            btn.innerHTML = `&#${parseInt(icons[v],16)};`;
            return btn;
        });
        if(aplayer.fixed){
            if(aplayer.fixed===!0)aplayer.fixed='right|bottom';
            const fixed = aplayer.fixed.split('|');
            let fixedCSS = `position: fixed;height:${bodyHeight};max-width:${bodyWidth};`;
            I.toArr(this.fixedPOS,v=>{
                if(!fixed.includes(v)&&fixed.length==1)fixedCSS+=v+':'+0+';';
                else if(fixed.includes(v)) fixedCSS += v+':'+(v=='bottom'?'80px;':'20px;');
            });
            if(fixed.length==1)fixedCSS+='margin:auto;margin-'+fixed[0]+':0px;';
            css.addRule(`&{${fixedCSS}}`);
            css.pushCSS(`opacity: 0.8;`,bodyElmIndex);
            css.addRule(`&:hover ${css.ElmId(bodyElm)}{opacity: 1;}`);
            let lrctop = `position: absolute;right: 0px;width:${bodyWidth};`;
            lrctop+= this.fixed=='top'?'top:100%;':'bottom:100%;';
            css.Elm2Rule(lrcElm,lrctop);
            css.pushCSS(`overflow: hidden;height:100px;background: transparent;`,lrcElmIndex);
            this.isFixed = !0;
        }else{
            css.addRule(`&{margin:5px auto;position: relative;}`);
        }
        if(I.bool(aplayer.mini)){
            //是否最小化
            const switchElm = this.appendChild(this.creatElm('div'),bodyElm);
            css.Elm2Rule(switchElm,`
            background: #e6e6e6;
            ${fontface}
            line-height:${bodyHeight};
            text-align:center;
            width:15px;
            border-radius: 0 2px 2px 0;order:4;`);
            switchElm.innerHTML = '&#'+parseInt(icons.right,16)+';';
            css.addRule(`&.active{max-width:81px !important;position: fixed;top:unset;left:unset;right: 10px;bottom: 80px;margin:unset;}`);
            css.addRule(`&.active ${css.ElmId(infoElm)}{flex-grow:0;width:0px;padding:0px;overflow: hidden;}`);
            css.addRule(`&.active ${css.ElmId(infoElm)} *{display:none;}`);
            css.addRule(`&.active ${css.ElmId(switchElm)}{transform: rotate(180deg);order:1 !important;}`);
            css.addRule(`&.active ${css.ElmId(lrcElm)}{position: absolute;bottom: 100%;top:unset;right: 0px;width:${bodyWidth};}`);
            function onSwitch(e){
                if(e)aplayer.mini = !aplayer.mini;
                aplayer.container.classList[aplayer.mini?'add':'remove']('active');
            }
            switchElm.on('click',onSwitch);
            onSwitch();
        }
        //艺术图 按钮
        const picbtn = this.appendChild(this.creatElm('div'),picElm);
        css.Elm2Rule(picbtn,`
        position: absolute;
        border-radius: 50%;
        opacity: 0.8;
        border: 2px solid #fff;
        text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);
        box-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);
        background: rgba(0, 0, 0, 0.2);
        transition: all 0.1s ease;
        cursor: pointer;
        inset:4px;
        color:#fff;
        ${fontface}`);
        css.Elm2Rule(picbtn,`
        width: 26px;
        height: 26px;
        line-height: 26px;
        margin:auto;
        font-size: 32px;
        text-indent: 7px;`,!0,'.active');
        css.Elm2Rule(picbtn,`
        width: 16px;
        height: 16px;
        top: unset;
        left: unset;
        bottom: 4px;
        right: 4px;
        text-indent: 5px;
        line-height: 16px;
        font-size: 12px;`,!0,':not([class~="active"])');
        aplayer.on('play',e=>{
            aplayer.isPlay = e.detail||false;
            picbtn.classList[!aplayer.isPlay?'add':'remove']('active');
            picbtn.innerHTML = '&#'+parseInt(icons[!aplayer.isPlay?'play':'pause'],16)+';';
        });
        picElm.on('click',function(e){
            if(!aplayer.audio.length)return;
            const audio = aplayer.audioElm;
            audio[audio.paused?'play':'pause']();
        });
        aplayer.toEvent('play',!1);
        Object.assign(aplayer.Elm,{
            lrc:lrcElm,
            lrctext:lrcTextElm,
            //timebar:barWidthElm,
            //barthum:barThumbElm,
            //starTimeElm,
            //endTimeElm,
            'title':titleElm,
            'author':authorElm,
            'list':listUlElm,
        });
        Object.assign(aplayer.RuleKey,{
            picindex,
        })
        this.css = css;
        this.appendChild(HTML);
        this.initAudio();
    }
    fixedPOS = ['top','right','bottom','left'];
    addMusic(data,bool){
        if(I.array(data))return this.play(I.toArr(data,v=>this.addMusic(v,!0)));
        const index = this.audio.length;
        if(!data||!data.url)return;
        data = Object.assign({
            name:'网络歌曲'+index,
            artist:'未知艺术家'
        },data);
        this.audio.push(data);
        this.appendChild(this.setMusic(data,index),this.Elm['list']);
        if(bool) return index;
        this.play(index);
    }
    outMusic(elm){
        if(!elm)elm = this.Elm['list'];
        elm.innerHTML = ''; 
        I.toArr(this.audio,(entry,k)=>this.appendChild(this.setMusic(entry,k),elm));
    }
    setMusic(data,index){
        const aplayer = this;
        const li = aplayer.creatElm('li');
        const name = aplayer.appendChild(aplayer.creatElm('span'),li);
        const artist = aplayer.appendChild(aplayer.creatElm('span'),li);
        if(I.buf(data.url)||I.blob(data.url)){
            data.url = F.URL(data.url,F.getMime('mp3'));
        }
        name.innerHTML = data.name;
        artist.innerHTML = data.artist;
        li.setAttribute('data-index',index);
        li.on('pointerup',function(e){
            aplayer.play(parseInt(this.dataset.index));
        });
        return li;
    }
    async readLRC(){
        const aplayer = this;
        const index = this.index;
        const data = aplayer.getData();
        let lrc = data.lrc;
        if(!lrc)return aplayer.setLRC([]);
        if(I.array(lrc)) return aplayer.setLRC();
        aplayer.setLRC([['00:00', 'Loading']]);
        if(I.str(lrc)&&/\.lrc$/i.test(lrc)){
            lrc = await aplayer.Store.ajax({
                url:lrc,
                key:F.getName(lrc),
                charset:data.charset,
                type:'text'
            },!0);
        }else if(I.blob(lrc)){
            lrc = I.decode(await I.toU8(lrc));
        }
        this.audio[index].lrc = aplayer.parseLRC(lrc);
        aplayer.setLRC();
    }
    updateLRC(time){
        const aplayer = this;
        if(aplayer.hideLRC) return;
        const data = aplayer.getData();
        let lrc = data&&data.lrc;
        let index=0;
        let height = 0;
        let elms = aplayer.Elm['lrctext'].children;
        index = I.array(lrc)&&lrc.filter((v,k)=>{
            if(elms[k])elms[k].classList.remove('active');
            const bool = v[0]<time;
            if(bool){
                if(elms[k]){
                    height+=elms[k].getBoundingClientRect().height;
                }
            }
            return bool;
        }).length;
        if(index)elms[index-1].classList.add('active');
        aplayer.Elm['lrctext'].style.cssText = `transform: translateY(-${height}px);`;

    }
    setLRC(lrc){
        if(lrc==false)lrc = [];
        const data = this.getData();
        lrc = lrc||data.lrc;
        let html = I.toArr(lrc,entry=>{
            return `<p>${entry[1]}</p>`;
        }).join('');
        if(html){
            this.Elm['lrctext'].innerHTML = html;
            if(this.hideLRC) return;
            this.Elm['lrc'].hidden = !1;
        }else{
            this.Elm['lrc'].hidden = !0;
        }
    }
    /**
     * Parse lrc, suppose multiple time tag
     *
     * @param {String} lrcText - Format:
     * [mm:ss]lyric
     * [mm:ss.xx]lyric
     * [mm:ss.xxx]lyric
     * [mm:ss.xx][mm:ss.xx][mm:ss.xx]lyric
     * [mm:ss.xx]<mm:ss.xx>lyric
     *
     * @return {String} [[time, text], [time, text], [time, text], ...]
     */
    parseLRC(lrcText) {
        if (lrcText) {
            lrcText = lrcText.replace(/([^\]^\n])\[/g, (match, p1) => p1 + '\n[');
            const lyric = lrcText.split('\n');
            let lrc = [];
            const lyricLen = lyric.length;
            for (let i = 0; i < lyricLen; i++) {
                // match lrc time
                const lrcTimes = lyric[i].match(/\[(\d{2}):(\d{2})(\.(\d{2,3}))?]/g);
                // match lrc text
                const lrcText = lyric[i]
                    .replace(/.*\[(\d{2}):(\d{2})(\.(\d{2,3}))?]/g, '')
                    .replace(/<(\d{2}):(\d{2})(\.(\d{2,3}))?>/g, '')
                    .replace(/^\s+|\s+$/g, '');

                if (lrcTimes) {
                    // handle multiple time tag
                    const timeLen = lrcTimes.length;
                    for (let j = 0; j < timeLen; j++) {
                        const oneTime = /\[(\d{2}):(\d{2})(\.(\d{2,3}))?]/.exec(lrcTimes[j]);
                        const min2sec = oneTime[1] * 60;
                        const sec2sec = parseInt(oneTime[2]);
                        const msec2sec = oneTime[4] ? parseInt(oneTime[4]) / ((oneTime[4] + '').length === 2 ? 100 : 1000) : 0;
                        const lrcTime = min2sec + sec2sec + msec2sec;
                        lrc.push([lrcTime, lrcText]);
                    }
                }
            }
            // sort by time
            lrc = lrc.filter((item) => item[1]);
            lrc.sort((a, b) => a[0] - b[0]);
            return lrc;
        } else {
            return [];
        }
    }
    fontData(){
        return I.toCp437('wOF2\0☺\0\0\0\0♣\0\0♂\0\0\0\0♂░\0\0♦│\0☺\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0∟T♠V\0ä4◙êdçK☺6☻$♥@♂"\0♦ ♣ä◙•üA←-◙QöPN•┘W╪öß^$═∞ε¼♥↨{∞Öƒ╟♪∞≡#↑Dá7↑)\0► └Çⁿ\tµz∩}3íÖ$¢▌╨•└╓♥j"○¼*æ6-/◘[8▲-○Sv§µ╗Ω⌂5ù√ä▓Ç\'LΦeæ§ÉΩ▄\'¢Σ■`/╪╛pUóJwJÉ╗k╡º¶♥♂<j-ÉH☻ü@+ÇÇÄ°è▐╫Ä╪■\t÷⌂Mφσ└╒☺Ç¼╖@╣ⁿ☻ÄêTφ¶=?♪B☺üÜ»≥│¢╤v►P╗Ü≥1k♥_╟»Ç\0c┼æf╗zxåΘΣÑü♪m÷FB6æS$∟·F+M3Φ#╖ß║╛╧8Ç╠◙ÇÄΣÜ╚₧!£♀√╥▌π2éô≈╒î\0HP☼P₧δ\0¶`a?♣ε╞▐sZ¿+[Lo█&░»â◘k╡?k♀◙α^\t═‼èµpy|☺├◙Eb5`└▲▼☻Ç╧⌠╒`ì▲""☺☺)►É♠☺9  ↨♦ΣüÇ|►P\0☻2  ♂☻◙A@◄◘(♠☺╒αQ♂$☺ì0û♂Ç•l┼§úIh↕↔FèP¶:S£→♦qöτJW£║₧U ◘⌠j┌←⌠û)→·▲e♣ô╡:Σ═n▐_☺7Üi╥─w∞GFS¶$╦╥2┐╤2ª(ΘV█¬¥╗<3╝Y┌n≈fº0↔╥╢ká►J(╕r¡‼¼P▀2ƒgy▒╗╠-═─£╒↓¢gτò▬e☺3_☺╚L!╪═ª!År\0`P◄0Fí~æí░╣aû│♫ìæ╚▄a░Φ/g\'φFQ┬j═╠-╠≡╩w╕┘φVφ6n┤Ü¥¢¥N│╒║Q╚Tφ-╟¢TO↨┘♠½╦∙¢sdn6ìfΣ¼♠♣²í7τ♪¢-╨▌╢╢Ω▬çu╠äàY§¡•╝╧·ⁿ♪δ♦≡WIC\\)Θ╟▀ê?↓≡└n║▄}Ç╕─♠ë║$$←+j<◄☻DC7 ¥)╔°╢▓k§ Æ$s3⌂ƒA`u╫♀+5WπⁿI√╜Zo∟←‼_>╣Z⌂╥Ö;▐↑╙êR\t⌡+?┼VJ↓ñ#╧K¶IæöB→"╝1§íα^¼w∞╨ë/┐Γ╒╩↨∞⌡9"Γ`åºÆìíq@≡Çó\tK4ó┬↔φ(6½╔╜▒wR◄☻ò«Ω╒T•C¶♦T♪Cî☺ƒù∩o╖•~Ç}‼╢w⌂├üΩ84RB╝YüF\\O▬jα╤n╦²▲τ°"H←«⌂v}▌♠┬ûr╚╢2╖)┼l¿K9b]YZ█╬Ç↔┬ó¼↑╦·╓°¡!¢→\0┬Åccφα┐o1☻Ç⌂oM╔ad₧ZƒΦî∩²b`¶¼ç²Ióv*○v╓☺♠<iñ╢\0gcúQ╣◄∙τ○H\\Ω\0\0☺↑♠░>?√[│₧<ßn@xN8♥%┼áÑ▄φ░♠▄.╧┤█ÿτ^oÑ>┤░♦á╪♣○D║♦Jz\0ZΩ╕↔à_╖+÷╤m∟⌠\t∟kΩ╨±╘◄!ÖGL*┼s#↕┌^1/D;♂\\┐Rëk4ÿ≤↕#6_▓óNfe↓│8\'═«╚ö¿¶1¢╙☻├╥M╦╥εy^▄⌠τ▄É4äR♫!DîG(QQ╕╝yà┬≡W(W↑Av╟♦\\~7\\╦F─ƒ+íΦ╝╣%ªPK╠öNuîy│sDc«F♣♣‼JI╨M╢═▌♂(Tj]ΘênkÅτöïEew]ª_╟5*§K◙§5↔║⌠Φ3áíe╚ê1kLXG{+╛∞X^§8¿IU→¥╩ÄÆ■ê╛╠╨╕ÜΓxLyä╣ôs‼æ▲jOPó(█→M╒WD╓ßJ┼F28H↑àδ=ÉG┬$¥\\$i┘.ñ░-òç\0');
    }
}